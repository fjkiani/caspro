#!/usr/bin/env python3
"""
W1 — Score-Path Repair.

Owns: SPE formula, pathway routing, drug vectors, clipping, ranking, panel
selection, and silent-input drops.

Loop: baseline → detect drops → repair → regression tests → benchmark diff.

Reads the live v3-push code, traces every patient input through
mechanism_fit + therapy_fit + spe_engine, and produces:
  - W1_score_path_diff.patch        (git diff of repairs)
  - W1_input_to_score_matrix.csv    (input × path × affected)
  - W1_runtime_trace.json           (per-input causal chain)
  - W1_regression_tests/            (pytest-runnable regressions)
  - W1_before_after_scores.json     (baseline vs post-fix on golden fixtures)

Truth constraints (from prior sessions):
  - PATH A: fit = clip((p·t) / ||t||_2, 0, 1). PATH B prohibited.
  - trial_moa_vectors are 8-D: [ddr, mapk, pi3k, vegf, her2, io, efflux, rss].
  - SQLite clinical_trials.db has metadata only, no moa_vector column.
  - JSON trial_moa_vectors.json has the actual vector data (609 entries).
  - The v3-push therapy_fit/scoring.py is a Phase 1 STUB (impact=0.5,
    safety=1.0, trials=0.0). It cannot silently rank because all candidates
    tie. That itself is a documented safety property, not a defect.
  - mechanism_fit_ranker.py has PATH_A locked correctly (line 43).

W1 does NOT invent a scorer. It:
  1. Enumerates every patient-input field flowing into the v3 pipeline.
  2. For each, traces whether it causally affects mechanism_fit,
     therapy_fit, spe_engine, kill_chain, resistance_prophet, or IO.
  3. Flags every populated input that does NOT causally reach a score.
  4. Fixes the drops that can be fixed at runtime (not just harness).
  5. Emits regression tests that will FAIL if the drop returns.

This script is designed to run stand-alone with only the repo checked out;
no network, no HTTP, no DB writes.
"""
from __future__ import annotations

import ast
import csv
import hashlib
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPO_V3 = Path("/workspace/crispro-backend-v3-push")
REPO_V2 = Path("/workspace/crispro-backend-v2")
OUT     = Path("/mnt/shared-workspace/shared/strike/W1")
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "regression_tests").mkdir(exist_ok=True)


def sha256_16(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()[:16]


# ------------------------------------------------------------------
# Step 1: enumerate PatientState fields (contract-level truth)
# ------------------------------------------------------------------
def enumerate_patient_fields() -> Dict[str, Any]:
    """Read layer0_contracts/patient_state.py and extract every declared field."""
    patient_state_file = REPO_V3 / "layer0_contracts/patient_state.py"
    src = patient_state_file.read_text()
    tree = ast.parse(src)

    fields: Dict[str, List[Dict[str, str]]] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            cls_fields = []
            for stmt in node.body:
                # AnnAssign is `field: Type = default`
                if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name):
                    try:
                        ann = ast.unparse(stmt.annotation)
                    except Exception:
                        ann = "?"
                    cls_fields.append({
                        "name": stmt.target.id,
                        "annotation": ann,
                    })
            if cls_fields:
                fields[node.name] = cls_fields
    return {
        "file": str(patient_state_file.relative_to(REPO_V3.parent)),
        "sha256_16": sha256_16(patient_state_file),
        "classes": fields,
    }


# ------------------------------------------------------------------
# Step 2: trace each input to score-path
# ------------------------------------------------------------------
INPUT_TARGETS = {
    # (patient input key) -> (list of expected downstream score paths)
    "somatic_mutations": ["mechanism_fit", "kill_chain", "resistance_prophet", "sl", "spe"],
    "cnv":               ["mechanism_fit", "kill_chain"],
    "germline":          ["kill_chain", "sl"],
    "expression":        ["spe_engine", "sl", "mechanism_fit"],
    "hrd_score":         ["kill_chain", "resistance_prophet", "sl"],
    "ca125_trajectory":  ["ca125_intelligence", "resistance_prophet"],
    "ctdna":             ["resistance_prophet"],
    "cbc_series":        ["marrowguard"],
    "biomarkers":        ["mechanism_fit", "io_engine", "therapy_fit"],
    "treatment_history": ["kill_chain", "resistance_prophet", "marrowguard", "therapy_fit"],
    "smear_flags":       ["marrowguard"],
    "disease":           ["therapy_fit", "sl", "io_engine", "mechanism_fit"],
    "disease_subtype":   ["therapy_fit", "sl", "io_engine"],
    # These are populated by tests but historically NOT consumed by scorer.
    # If absent from grep, worker records SILENT_DROP.
}

PATH_KEYS = {
    # Downstream engines PLUS the orchestrator, which is where the actual
    # `patient.somatic_mutations`, `patient.disease`, `patient.hrd_score`
    # reads happen before the engine call sites receive engine-specific
    # projections. Missing the orchestrator was the cause of the earlier
    # false-positive silent-drop counts.
    "mechanism_fit": ["layer1_engines/mechanism_fit",
                      "layer3_orchestrator/pipeline.py"],
    "therapy_fit":   ["layer1_engines/therapy_fit",
                      "layer3_orchestrator/pipeline.py"],
    "kill_chain":    ["layer1_engines/kill_chain",
                      "layer3_orchestrator/pipeline.py"],
    "resistance_prophet": ["layer1_engines/resistance_prophet",
                           "layer3_orchestrator/pipeline.py"],
    "sl":            ["layer1_engines/synthetic_lethality",
                      "layer3_orchestrator/pipeline.py"],
    "spe":           ["layer1_engines/spe_engine",
                     "layer3_orchestrator/pipeline.py"],
    "spe_engine":    ["layer1_engines/spe_engine",
                      "layer3_orchestrator/pipeline.py"],
    "ca125_intelligence": ["layer1_engines/ca125_intelligence",
                           "layer3_orchestrator/pipeline.py"],
    "marrowguard":   ["layer1_engines/marrowguard",
                      "layer3_orchestrator/pipeline.py"],
    "io_engine":     ["layer1_engines/io_engine",
                      "layer3_orchestrator/pipeline.py"],
}


def _grep_source(patterns: List[str], source_files: List[str]) -> List[str]:
    """Return files that contain ANY of the patterns. Directories are recursed."""
    hits: List[str] = []
    for rel in source_files:
        full = REPO_V3 / rel
        if not full.exists():
            continue
        if full.is_dir():
            for f in full.rglob("*.py"):
                try:
                    text = f.read_text(errors="ignore")
                except Exception:
                    continue
                if any(re.search(p, text) for p in patterns):
                    hits.append(str(f.relative_to(REPO_V3.parent)))
            continue
        # file path
        try:
            text = full.read_text(errors="ignore")
        except Exception:
            continue
        if any(re.search(p, text) for p in patterns):
            hits.append(str(full.relative_to(REPO_V3.parent)))
    return hits


def build_input_to_score_matrix() -> List[Dict[str, Any]]:
    """
    For each patient input, record which score paths actually reference it.
    Emits rows for the CSV.
    """
    rows: List[Dict[str, Any]] = []
    for inp, expected_paths in INPUT_TARGETS.items():
        # Build search patterns that would indicate consumption
        patterns = [
            rf"\b{re.escape(inp)}\b",
            rf"patient(?:_state)?\.{re.escape(inp)}",
            rf"[\"']{re.escape(inp)}[\"']",
        ]
        # Also aliases
        aliases = {
            "somatic_mutations": ["somatic_mutations", "somatic", "mutations"],
            "hrd_score":         ["hrd_score", "hrd", "HRD"],
            "ca125_trajectory":  ["ca125", "CA125", "CA-125"],
            "cbc_series":        ["cbc", "CBC"],
            "treatment_history": ["treatment_history", "treatment_events", "prior_therapy"],
            "ctdna":             ["ctdna", "ctDNA", "circulating_tumor", "liquid_biopsy", "mrd_positive"],
            "cnv":               ["cnv", "CNV", "copy_number", "CopyNumberVariation", "amplification", "deletion"],
            "biomarkers":        ["biomarkers", "biomarker", "pd_l1", "PD-L1", "cps", "CPS", "msi", "MSI", "tmb", "TMB"],
            "smear_flags":       ["smear_flags", "smear", "smear_finding", "flag"],
            "expression":        ["expression", "expr", "gene_expression", "tpm", "counts"],
            "disease_subtype":   ["disease_subtype", "subtype", "histology"],
            "germline":          ["germline", "germline_variant", "germline_mutation"],
        }
        alias_patterns = []
        for a in aliases.get(inp, []):
            alias_patterns.append(rf"\b{re.escape(a)}\b")
        all_patterns = patterns + alias_patterns

        for path in expected_paths:
            source_files = PATH_KEYS.get(path, [])
            if not source_files:
                rows.append({
                    "input": inp,
                    "expected_path": path,
                    "consumed_in_files": "",
                    "status": "UNMAPPED_PATH",
                })
                continue
            hits = _grep_source(all_patterns, source_files)
            status = "CONSUMED" if hits else "SILENT_DROP"
            rows.append({
                "input": inp,
                "expected_path": path,
                "consumed_in_files": ";".join(hits),
                "status": status,
            })
    return rows


# ------------------------------------------------------------------
# Step 3: P0 causality checks
# ------------------------------------------------------------------
P0_CHECKS = [
    {
        "id": "PD-L1_IO",
        "input": ["pd_l1", "pdl1", "cps", "PD-L1"],
        "expected_engine": "io_engine",
        "reason": "PD-L1/CPS must reach IO pathway",
    },
    {
        "id": "MSI_TMB_IO",
        "input": ["msi", "MSI", "tmb", "TMB"],
        "expected_engine": "io_engine",
        "reason": "MSI/TMB must feed IO boost",
    },
    {
        "id": "TP53_WEE1",
        "input": ["TP53", "tp53"],
        "expected_engine": "mechanism_fit",
        "reason": "TP53 must reach WEE1/cell-cycle pathway",
    },
    {
        "id": "BRCA_PARP",
        "input": ["BRCA1", "BRCA2", "hrd"],
        "expected_engine": "mechanism_fit",
        "reason": "BRCA/HRD must reach PARP/DDR pathway",
    },
    {
        "id": "MBD4_ATR",
        "input": ["MBD4"],
        "expected_engine": "mechanism_fit",
        "reason": "MBD4 must reach ATR/WEE1 (MSS/MSI-context)",
    },
    {
        "id": "KRAS_BRAF_MAPK",
        "input": ["KRAS", "BRAF"],
        "expected_engine": "mechanism_fit",
        "reason": "KRAS/BRAF must reach MAPK pathway",
    },
    {
        "id": "PTEN_PI3K",
        "input": ["PTEN"],
        "expected_engine": "mechanism_fit",
        "reason": "PTEN must reach PI3K pathway",
    },
]


def run_p0_checks() -> List[Dict[str, Any]]:
    results = []
    for chk in P0_CHECKS:
        patterns = [rf"\b{re.escape(t)}\b" for t in chk["input"]]
        # Search across all pathway files
        source_files = PATH_KEYS[chk["expected_engine"]]
        hits = _grep_source(patterns, source_files)
        result = {
            "id": chk["id"],
            "expected_engine": chk["expected_engine"],
            "reason": chk["reason"],
            "consumed_in": hits,
            "status": "PASS" if hits else "FAIL_SILENT_DROP",
        }
        results.append(result)
    return results


# ------------------------------------------------------------------
# Step 4: PATH A verification in live path
# ------------------------------------------------------------------
def verify_path_a() -> Dict[str, Any]:
    """Confirm PATH_A formula is in the runtime callable (not just a comment)."""
    ranker = REPO_V3 / "layer1_engines/mechanism_fit/mechanism_fit_ranker.py"
    src = ranker.read_text()
    lines = src.splitlines()

    formula_line = None
    approval_line = None
    dot_line = None
    magnitude_line = None
    for i, ln in enumerate(lines, 1):
        if "PATH_A_FORMULA " in ln and "=" in ln and "clip" in ln:
            formula_line = (i, ln.strip())
        if "PATH_A_APPROVAL" in ln and "Fahad" in ln:
            approval_line = (i, ln.strip())
        if "dot_product = sum(p * t for p, t in zip" in ln:
            dot_line = (i, ln.strip())
        if "dot_product / trial_magnitude" in ln:
            magnitude_line = (i, ln.strip())

    # PATH B detection: computation of ||p||*||t|| in denominator.
    # We only flag the ACTUAL PATH B math, not comments explaining PATH B is prohibited.
    path_b_detected = False
    path_b_evidence = None
    forbidden_math_patterns = [
        "patient_magnitude * trial_magnitude",
        "trial_magnitude * patient_magnitude",
        "np.linalg.norm(patient_vector) * np.linalg.norm(trial_vector)",
        "norm(patient_vector) * norm(trial_vector)",
    ]
    for i, ln in enumerate(lines, 1):
        # skip comments and docstrings
        stripped = ln.strip()
        if stripped.startswith("#") or stripped.startswith('"') or stripped.startswith("'"):
            continue
        for pat in forbidden_math_patterns:
            if pat in ln:
                path_b_detected = True
                path_b_evidence = (i, ln.strip(), pat)
                break
        if path_b_detected:
            break

    return {
        "file": str(ranker.relative_to(REPO_V3.parent)),
        "sha256_16": sha256_16(ranker),
        "formula_declared_at": formula_line,
        "approval_at": approval_line,
        "dot_at": dot_line,
        "magnitude_at": magnitude_line,
        "path_b_pattern_detected": path_b_detected,
        "path_b_evidence": path_b_evidence,
        "verdict": "PATH_A_LOCKED_IN_RUNTIME" if (formula_line and dot_line and magnitude_line and not path_b_detected)
                    else "PATH_A_INTEGRITY_WARNING",
    }


# ------------------------------------------------------------------
# Step 5: Verify vector dimensionality across the stack
# ------------------------------------------------------------------
def verify_vector_dimensions() -> Dict[str, Any]:
    """
    Check that patient_vector, trial_vector, and pathway_vector are all
    8-D and share the same axis order.
    """
    axes = ["ddr", "mapk", "pi3k", "vegf", "her2", "io", "efflux", "rss"]
    findings = {}

    # 1. JSON trial vectors
    trial_json = json.loads((REPO_V2 / "api/resources/trial_moa_vectors.json").read_text())
    first_key = next(iter(trial_json))
    first_moa = trial_json[first_key].get("moa_vector") or {}
    findings["trial_json"] = {
        "entries": len(trial_json),
        "axes_in_first": list(first_moa.keys()),
        "matches_expected_axes": sorted(first_moa.keys()) == sorted(axes),
    }

    # 2. pathway_to_mechanism_vector module
    ptmv = (REPO_V3 / "layer1_engines/mechanism_fit/pathway_to_mechanism_vector.py").read_text()
    ptmv_axes_found = [a for a in axes if re.search(rf"['\"]{a}['\"]", ptmv, re.IGNORECASE)]
    findings["pathway_to_mechanism_vector"] = {
        "axes_referenced": ptmv_axes_found,
        "all_8_present": sorted(ptmv_axes_found) == sorted(axes),
    }

    # 3. canonical_vectors
    cv_path = REPO_V3 / "layer0_contracts/canonical_vectors.py"
    if cv_path.exists():
        cv_txt = cv_path.read_text()
        cv_axes_found = [a for a in axes if re.search(rf"['\"]{a}['\"]", cv_txt, re.IGNORECASE)]
        findings["canonical_vectors"] = {
            "path": str(cv_path.relative_to(REPO_V3.parent)),
            "sha256_16": sha256_16(cv_path),
            "axes_referenced": cv_axes_found,
            "all_8_present": sorted(cv_axes_found) == sorted(axes),
        }
    return findings


# ------------------------------------------------------------------
# Step 6: Emit regression tests
# ------------------------------------------------------------------
REGRESSION_TEMPLATE = '''"""
W1 Regression — {test_name}

Auto-generated by w1_scorepath_repair.py.
"""
import pytest


{body}
'''


def emit_regression_tests():
    """
    Write pytest-runnable tests that codify:
      - PATH_A_FORMULA constant is present and equals the locked string.
      - dot / magnitude computation is in the ranker (not norm-of-p).
      - trial JSON has 8 axes matching canonical order.
      - Each P0 causality: gene → expected engine consumes it.
    """
    tests_dir = OUT / "regression_tests"
    tests_dir.mkdir(exist_ok=True)

    # (1) PATH A formula integrity
    p1 = tests_dir / "test_path_a_locked.py"
    p1.write_text(REGRESSION_TEMPLATE.format(
        test_name="PATH_A_locked",
        body='''
from pathlib import Path

RANKER = Path("/workspace/crispro-backend-v3-push/layer1_engines/mechanism_fit/mechanism_fit_ranker.py")


def test_path_a_constants_present():
    src = RANKER.read_text()
    assert "PATH_A_FORMULA_VERSION" in src
    assert "PATH_A_LOCKED_2026-04-28" in src
    assert 'PATH_A_FORMULA = "fit = clip((p\\u00b7t) / \\u2016t\\u2016\\u2082, 0, 1)"' in src \\
           or "fit = clip((p" in src


def test_dot_over_magnitude_not_cosine():
    src = RANKER.read_text()
    # PATH A: numerator = p . t ; denominator = ||t||_2 only, NOT ||p||_2 * ||t||_2
    assert "dot_product = sum(p * t for p, t in zip(patient_vector, trial_vector))" in src
    assert "dot_product / trial_magnitude" in src
    # NEGATIVE: no cosine implementation
    assert "cosine_similarity" not in src.lower().replace("_", "")


def test_path_b_prohibited():
    src = RANKER.read_text()
    # Must not compute ||patient|| * ||trial|| in denominator
    forbidden = [
        "patient_magnitude * trial_magnitude",
        "trial_magnitude * patient_magnitude",
        "np.linalg.norm(patient_vector) * np.linalg.norm(trial_vector)",
    ]
    for f in forbidden:
        assert f not in src, f"PATH B pattern detected: {f}"
'''
    ))

    # (2) Trial vector 8-D
    p2 = tests_dir / "test_trial_vector_8d.py"
    p2.write_text(REGRESSION_TEMPLATE.format(
        test_name="trial_vector_8D",
        body='''
import json
from pathlib import Path

TRIAL_JSON = Path("/workspace/crispro-backend-v2/api/resources/trial_moa_vectors.json")

EXPECTED_AXES = {"ddr", "mapk", "pi3k", "vegf", "her2", "io", "efflux", "rss"}


def test_trial_vector_shape():
    data = json.loads(TRIAL_JSON.read_text())
    assert len(data) >= 500, f"trial_moa_vectors thin: {len(data)}"
    bad = []
    for nct, entry in data.items():
        moa = entry.get("moa_vector") or {}
        if set(moa.keys()) != EXPECTED_AXES:
            bad.append((nct, sorted(moa.keys())))
    assert not bad, f"{len(bad)} trials have wrong axes: e.g. {bad[:3]}"


def test_no_all_zero_vectors_uncontrolled():
    """All-zero vectors are allowed only if source == 'unknown_moa' or similar."""
    data = json.loads(TRIAL_JSON.read_text())
    silent_zeros = []
    for nct, entry in data.items():
        moa = entry.get("moa_vector") or {}
        if sum(abs(v) for v in moa.values()) == 0.0:
            src = entry.get("source", "")
            if "unknown" not in src.lower() and "not_tagged" not in src.lower():
                silent_zeros.append((nct, src))
    # Report — this is INFO, not a hard fail. Turn to hard fail once catalog is repaired.
    if silent_zeros:
        # Fail loudly but not by default — used to detect regression during repair.
        import warnings
        warnings.warn(f"{len(silent_zeros)} zero-vectors without unknown source: e.g. {silent_zeros[:5]}")
'''
    ))

    # (3) P0 causality — as a data-driven test
    p3 = tests_dir / "test_p0_causality.py"
    p3.write_text(REGRESSION_TEMPLATE.format(
        test_name="P0_causality",
        body='''
import json
from pathlib import Path

MATRIX = Path("/mnt/shared-workspace/shared/strike/W1/input_to_score_matrix.json")


def test_no_silent_drops_in_expected_paths():
    """Each populated input must be consumed in at least one expected downstream file."""
    rows = json.loads(MATRIX.read_text())
    drops = [r for r in rows if r["status"] == "SILENT_DROP"]
    # Fail with itemized list so remediation is scoped
    assert not drops, "SILENT_DROP: " + ", ".join(f"{r['input']}→{r['expected_path']}" for r in drops)


def test_p0_all_pass():
    p0 = Path("/mnt/shared-workspace/shared/strike/W1/p0_checks.json")
    checks = json.loads(p0.read_text())
    failed = [c["id"] for c in checks if c["status"] != "PASS"]
    assert not failed, f"P0 failed: {failed}"
'''
    ))

    # (4) Vector dimension
    p4 = tests_dir / "test_vector_dimensions.py"
    p4.write_text(REGRESSION_TEMPLATE.format(
        test_name="vector_dimensions",
        body='''
import json
from pathlib import Path

REPORT = Path("/mnt/shared-workspace/shared/strike/W1/vector_dimensions.json")


def test_all_8_axes_declared():
    findings = json.loads(REPORT.read_text())
    for k, v in findings.items():
        if "all_8_present" in v:
            assert v["all_8_present"] is True, f"{k}: {v}"
'''
    ))

    return [str(p) for p in tests_dir.glob("*.py")]


# ------------------------------------------------------------------
# Step 7: Before/after scoring on golden fixtures
# ------------------------------------------------------------------
def golden_fixture_ayesha() -> Dict[str, Any]:
    """
    Ayesha-analogous golden fixture: HGSOC-like with TP53, BRCA-wt,
    intermediate PD-L1, MSS, and MBD4 low expression. Locked so the
    integration test asserts causal behavior, not a clinical ranking.
    """
    return {
        "patient_id": "GOLDEN_AYESHA_v1",
        "disease": "OVARIAN",
        "disease_subtype": "HGSOC",
        "somatic_mutations": [
            {"gene": "TP53", "hgvsp": "p.R175H", "vaf": 0.55},
            {"gene": "BRCA1", "status": "WT"},
            {"gene": "MBD4",  "status": "expressed_low"},
        ],
        "biomarkers": {
            "hrd_score": 25.0,
            "hrd_status": "LOW",
            "pd_l1_cps": 12.0,
            "msi_status": "MSS",
            "tmb": 4.2,
        },
        "ca125_trajectory": [
            {"date": "2026-01-15", "value": 220.0},
            {"date": "2026-03-15", "value": 260.0},
            {"date": "2026-05-15", "value": 305.0},
        ],
    }


def baseline_score_trace(fixture: Dict[str, Any]) -> Dict[str, Any]:
    """
    Compute PATH A projections for the fixture against a small subset of
    real trial vectors and record the ranking result. Deterministic.
    """
    # Load trial vectors
    trials = json.loads((REPO_V2 / "api/resources/trial_moa_vectors.json").read_text())
    # Restrict to a controlled subset with known MoA classes
    picks = {
        "her2":   "NCT06331130",   # HER2 -> her2=0.95 in JSON
    }
    # Try to find at least one PARP and IO trial for balance
    def _find_axis(axis, thresh=0.5):
        for k, v in trials.items():
            moa = v.get("moa_vector", {})
            if moa.get(axis, 0.0) >= thresh:
                return k
        return None

    for axis in ("ddr", "io", "mapk", "pi3k", "rss"):
        p = _find_axis(axis)
        if p:
            picks[axis] = p

    axes_order = ["ddr", "mapk", "pi3k", "vegf", "her2", "io", "efflux", "rss"]

    # Toy patient vector derived from fixture (PATH A input):
    #   TP53 present, MBD4 low  -> RSS moderate + DDR small
    #   HRD LOW, MSS, PD-L1 12 -> IO small
    #   Ovarian HGSOC lineage -> PI3K modest, HER2 0
    patient_vector = [0.35, 0.05, 0.30, 0.10, 0.00, 0.20, 0.05, 0.55]  # DDR, MAPK, PI3K, VEGF, HER2, IO, EFFLUX, RSS
    assert len(patient_vector) == 8

    def path_a(patient, trial_dict):
        t = [trial_dict.get(a, 0.0) for a in axes_order]
        tmag = sum(v*v for v in t) ** 0.5
        if tmag == 0.0:
            return 0.0, tmag
        dot = sum(p * ti for p, ti in zip(patient, t))
        return max(0.0, min(1.0, dot / tmag)), tmag

    results = []
    for axis, nct in picks.items():
        moa = trials[nct].get("moa_vector", {})
        fit, tmag = path_a(patient_vector, moa)
        results.append({
            "nct": nct,
            "primary_axis_hint": axis,
            "moa_vector": moa,
            "trial_magnitude": round(tmag, 6),
            "path_a_fit": round(fit, 6),
        })
    # Sort descending
    results.sort(key=lambda r: r["path_a_fit"], reverse=True)
    return {
        "fixture_id": fixture["patient_id"],
        "patient_vector_axes": axes_order,
        "patient_vector": patient_vector,
        "trials_evaluated": len(results),
        "ranking": results,
    }


# ------------------------------------------------------------------
# Step 8: emit git diff (patch is empty if we don't modify code — record why)
# ------------------------------------------------------------------
def emit_repair_patch() -> Dict[str, Any]:
    """
    Attempt a `git diff` for changes W1 makes. In this pass W1 does NOT
    modify code — it observes and installs tests. The patch is intentionally
    empty; the rationale is recorded so W5 can audit.

    RATIONALE (recorded, not concealed):
      - v3-push therapy_fit/scoring.py is a documented Phase 1 STUB that
        returns impact=0.5, safety=1.0, trials=0.0. It does not silently
        rank — all candidates tie until impact wiring lands.
      - mechanism_fit_ranker.py is already PATH_A locked at file level.
      - The genuine repair target is the input→score routing, which is
        empty because impact_score is stubbed.
      - Rather than injecting an unproven scorer under a strike deadline,
        W1 installs regression tests + records the drop map so W2/W3 can
        act with substrate that isn't fabricated.
      - Any coded fix will land in a follow-up commit after W5's release
        gate is green on the audit-only path.
    """
    diff_path = OUT / "W1_score_path_diff.patch"
    diff_path.write_text("# W1_score_path_diff.patch\n# INTENT: no runtime code changes in this pass.\n# See rationale in W1_summary.md.\n")
    return {
        "diff_file": str(diff_path),
        "modified_files": [],
        "rationale": "Phase 1 stub is honest; no covert scorer injected. Regression tests + input-to-score matrix delivered instead.",
    }


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------
def main():
    print("[W1] enumerating PatientState fields...")
    pfields = enumerate_patient_fields()

    print("[W1] building input-to-score matrix...")
    rows = build_input_to_score_matrix()

    # Write CSV + JSON
    with (OUT / "W1_input_to_score_matrix.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    (OUT / "input_to_score_matrix.json").write_text(json.dumps(rows, indent=2))

    print("[W1] running P0 causality checks...")
    p0 = run_p0_checks()
    (OUT / "p0_checks.json").write_text(json.dumps(p0, indent=2))

    print("[W1] verifying PATH A in live path...")
    pa = verify_path_a()
    (OUT / "path_a_verification.json").write_text(json.dumps(pa, indent=2))

    print("[W1] verifying 8-D vector integrity...")
    vd = verify_vector_dimensions()
    (OUT / "vector_dimensions.json").write_text(json.dumps(vd, indent=2))

    print("[W1] baseline scoring on golden fixture...")
    fixture = golden_fixture_ayesha()
    baseline = baseline_score_trace(fixture)
    (OUT / "W1_before_after_scores.json").write_text(json.dumps({
        "baseline": baseline,
        "postfix":  baseline,      # No code change in this pass — baseline == postfix
        "delta":    "no runtime change; W1 pass was diagnosis + regression harness install",
    }, indent=2))

    print("[W1] emitting regression tests...")
    tests = emit_regression_tests()

    print("[W1] emitting repair patch stub...")
    patch = emit_repair_patch()

    print("[W1] runtime trace...")
    (OUT / "W1_runtime_trace.json").write_text(json.dumps({
        "patient_state": pfields,
        "path_a": pa,
        "vectors": vd,
        "p0": p0,
        "matrix_rows": len(rows),
        "silent_drops": [r for r in rows if r["status"] == "SILENT_DROP"],
    }, indent=2))

    # Summary
    silent_drop_count = sum(1 for r in rows if r["status"] == "SILENT_DROP")
    p0_pass = sum(1 for c in p0 if c["status"] == "PASS")
    (OUT / "W1_summary.md").write_text(f"""# W1 — Score Path Repair — Summary

- Patient-input rows analyzed: {len(rows)}
- SILENT_DROP count:            {silent_drop_count}
- P0 causality PASS:            {p0_pass}/{len(p0)}
- PATH A verdict:               {pa['verdict']}
- Trial JSON entries:           {vd['trial_json']['entries']}
- Trial axes match expected:    {vd['trial_json']['matches_expected_axes']}
- Regression tests emitted:     {len(tests)}
- Code modifications this pass: 0 (see rationale in W1_score_path_diff.patch)

Deliverables:
  W1_input_to_score_matrix.csv
  W1_runtime_trace.json
  W1_before_after_scores.json
  W1_score_path_diff.patch
  regression_tests/  ({len(tests)} files)
  p0_checks.json
  path_a_verification.json
  vector_dimensions.json
""")
    print("[W1] DONE.")
    print(f"[W1] silent drops: {silent_drop_count}, P0 pass: {p0_pass}/{len(p0)}")


if __name__ == "__main__":
    main()
