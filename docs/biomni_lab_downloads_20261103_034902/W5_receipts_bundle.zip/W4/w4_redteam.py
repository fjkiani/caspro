#!/usr/bin/env python3
"""
W4 — Confidence Red-Team / Dominance / Clip / Governance.

Owns: confidence layer, gates (governance, mmr, platinum, feasibility,
evidence_tier, confidence_cap, liver_metastasis, ptmb), fail-closed
semantics, contamination guards, output tier labeling.

Loop:
  1. Read every layer2_gates/*.py in v3-push. Extract each gate's
     pass/fail predicate and its declared side-effect (rank=999, cap,
     block claim, disclosure).
  2. Read layer1_engines/confidence + holistic_score for the
     computation path.
  3. Look for governance_gate BLOCKED_CLAIMS list and cross-check
     against every text emission surface (reports, receipts, formatters).
  4. Design adversarial attacks:
       - Push through a BLOCKED_CLAIM string via context field
       - Trigger a fail-closed path with malformed input
       - Bypass mmr_gate via missing MSI status
       - Bypass platinum_gate via missing prior-therapy history
       - Force IO recommendation with silent PD-L1 drop
       - Feed all-zero patient vector; check whether ANY tier is
         still emitted vs LOCKED_NO_EXPRESSION
  5. Emit findings + recommended runtime patches (advisory).

Deliverables:
  W4_gate_map.json
  W4_governance_registry.json
  W4_redteam_findings.md
  W4_attack_matrix.csv
  W4_confidence_cap_receipts.json
"""
from __future__ import annotations

import ast
import csv
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

REPO_V3 = Path("/workspace/crispro-backend-v3-push")
OUT = Path("/mnt/shared-workspace/shared/strike/W4")
OUT.mkdir(parents=True, exist_ok=True)


# ------------------------------------------------------------------
# 1) Gate map — enumerate each L2 gate + its predicate signatures
# ------------------------------------------------------------------
def enumerate_gates() -> Dict[str, Any]:
    gate_dir = REPO_V3 / "layer2_gates"
    gates = {}
    for p in gate_dir.glob("*.py"):
        if p.name == "__init__.py":
            continue
        src = p.read_text(errors="ignore")
        # Parse AST for functions and top-level constants
        try:
            tree = ast.parse(src)
        except SyntaxError:
            continue
        funcs = []
        consts = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                funcs.append({
                    "name": node.name,
                    "args": [a.arg for a in node.args.args],
                    "lineno": node.lineno,
                })
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id.isupper():
                        try:
                            consts[target.id] = ast.unparse(node.value)[:200]
                        except Exception:
                            consts[target.id] = "?"
        gates[p.name] = {
            "path":    str(p.relative_to(REPO_V3.parent)),
            "sha256":  hashlib.sha256(p.read_bytes()).hexdigest()[:16],
            "lines":   src.count("\n") + 1,
            "functions": funcs,
            "constants": consts,
        }
    return gates


# ------------------------------------------------------------------
# 2) Governance registry — pull BLOCKED_CLAIMS + PERMANENTLY_CLOSED
# ------------------------------------------------------------------
def extract_governance() -> Dict[str, Any]:
    gg = REPO_V3 / "layer2_gates/governance_gate.py"
    src = gg.read_text()

    def _extract_literal_list(name: str) -> List[str]:
        # Match `NAME: FrozenSet[str] = {"a","b",...}` or `NAME = [...]` etc.
        # We use a light-touch regex first, then AST for verification.
        m = re.search(
            rf"^{re.escape(name)}\s*(?::[^=]+)?=\s*(\{{[^\}}]*\}}|\[[^\]]*\])",
            src, re.MULTILINE | re.DOTALL,
        )
        if not m:
            return []
        blob = m.group(1)
        return re.findall(r'"([^"]+)"', blob) + re.findall(r"'([^']+)'", blob)

    return {
        "path":               str(gg.relative_to(REPO_V3.parent)),
        "sha256":             hashlib.sha256(gg.read_bytes()).hexdigest()[:16],
        "BLOCKED_CLAIMS":     _extract_literal_list("BLOCKED_CLAIMS"),
        "PERMANENTLY_CLOSED": _extract_literal_list("PERMANENTLY_CLOSED"),
        "MANDATORY_DISCLOSURES": _extract_literal_list("MANDATORY_DISCLOSURES"),
        # PATH A literal
        "PATH_A_FORMULA_present": ('"fit = clip((p·t) / ‖t‖₂, 0, 1)"' in src or "PATH_A_FORMULA" in src),
    }


# ------------------------------------------------------------------
# 3) Egress surfaces — where text may leak
# ------------------------------------------------------------------
def egress_surfaces() -> List[Dict[str, Any]]:
    surfaces = []
    for root in ("layer4_output", "layer1_engines"):
        d = REPO_V3 / root
        for py in d.rglob("*.py"):
            try:
                text = py.read_text(errors="ignore")
            except Exception:
                continue
            emits = []
            for kw in ["print(", "return {", "logger.info", "logger.warning", "logger.error",
                       "raise", "yield", "response.body", "content = "]:
                if kw in text:
                    emits.append(kw)
            if emits:
                surfaces.append({
                    "path": str(py.relative_to(REPO_V3.parent)),
                    "kinds": emits,
                    "lines": text.count("\n") + 1,
                })
    return surfaces


# ------------------------------------------------------------------
# 4) BLOCKED_CLAIMS leak scan — do any egress files contain blocked strings?
# ------------------------------------------------------------------
def blocked_claim_leak_scan(blocked_claims: List[str]) -> List[Dict[str, Any]]:
    """
    For each blocked claim, search all L4 + L1 files for literal
    occurrences. A hit is only a *leak* if the file emits the claim as
    a positive assertion, not as a disclosure/quarantine reference.

    Heuristic:
      LEAK  = occurrence not on the same line (or adjacent line) as
              one of the guard tokens {QUARANTINED, quarantine, DISCLOSURE,
              disclosure, BLOCKED, blocked, prohibit, prohibited, BANNED, banned}.
      OK    = occurrence colocated with any guard token.

    The scan reports both kinds so W5 has full auditability, but 'verdict'
    on each finding tells you which is which.
    """
    # Guard tokens: any of these terms nearby means the occurrence is a
    # legitimate disclosure/quarantine reference, not a positive claim.
    # We also treat _STATUS, _DISCLOSURE, _GAP_FLAG suffixes on the SAME
    # line as guarded (these are constants explicitly marking a claim).
    # Guard tokens: any of these terms nearby means the occurrence is a
    # legitimate disclosure/quarantine reference, not a positive claim.
    # Underscore-prefixed tokens (_STATUS, _DISCLOSURE...) can't rely on
    # \b because `_` is a word character; use plain substring match for those.
    guard_word_re = re.compile(
        r"(?i)\b(?:quarantin|disclos|prohibit|blocked|banned|closed|advisory_only|do_not_emit|BLOCKED_CLAIMS|PERMANENTLY_CLOSED|gap_flag|mandatory_disclosure|exclusion_criter|conflict)"
    )
    guard_substrings = [
        "_STATUS", "_DISCLOSURE", "_GAP_FLAG", "_RATIONALE", "_WARNING",
        "_QUARANTINED", "_BLOCKED",
    ]
    def is_guarded(window: str) -> bool:
        if guard_word_re.search(window):
            return True
        return any(s in window for s in guard_substrings)
    findings = []
    for claim in blocked_claims:
        for py in list((REPO_V3 / "layer4_output").rglob("*.py")) + list((REPO_V3 / "layer1_engines").rglob("*.py")):
            if py.name == "governance_gate.py":
                continue
            try:
                text = py.read_text(errors="ignore")
            except Exception:
                continue
            if claim in text:
                lines = text.splitlines()
                hit_lines = []
                for i, ln in enumerate(lines):
                    if claim in ln:
                        # Look at a wider window: 8 lines above (rationale
                        # blocks often start with a guard header) and 2
                        # lines below. Also mark guarded if the enclosing
                        # constant name contains a guard token.
                        window = "\n".join(lines[max(0, i - 8): i + 3])
                        guarded = is_guarded(window)
                        hit_lines.append({
                            "lineno":  i + 1,
                            "guarded": guarded,
                            "excerpt": ln.strip()[:180],
                        })
                unguarded = [h for h in hit_lines if not h["guarded"]]
                findings.append({
                    "claim":            claim,
                    "path":             str(py.relative_to(REPO_V3.parent)),
                    "total_occurrences": len(hit_lines),
                    "guarded_occurrences": sum(1 for h in hit_lines if h["guarded"]),
                    "unguarded_occurrences": len(unguarded),
                    "verdict":          "LEAK" if unguarded else "REFERENCE_ONLY",
                    "sample_lines":     hit_lines[:5],
                })
    return findings


# ------------------------------------------------------------------
# 5) Confidence + holistic_score inspection
# ------------------------------------------------------------------
def inspect_confidence() -> Dict[str, Any]:
    files = {
        "confidence":     REPO_V3 / "layer1_engines/confidence",
        "holistic_score": REPO_V3 / "layer1_engines/holistic_score",
    }
    out = {}
    for name, path in files.items():
        if not path.exists():
            out[name] = {"present": False}
            continue
        pyfiles = list(path.rglob("*.py"))
        info = {"present": True, "files": []}
        for py in pyfiles:
            try:
                text = py.read_text(errors="ignore")
            except Exception:
                continue
            info["files"].append({
                "path": str(py.relative_to(REPO_V3.parent)),
                "sha":  hashlib.sha256(py.read_bytes()).hexdigest()[:16],
                "lines": text.count("\n") + 1,
                "has_cap_logic":     ("cap" in text.lower() or "clip" in text.lower()),
                "has_fail_closed":   ("FAIL_CLOSED" in text or "LOCKED_NO_EXPRESSION" in text or "quarantine" in text.lower()),
                "has_dominance":     ("dominance" in text.lower() or "single_axis" in text.lower()),
            })
        out[name] = info
    return out


# ------------------------------------------------------------------
# 6) Attack matrix design
# ------------------------------------------------------------------
ATTACKS = [
    {
        "id": "A1_blocked_claim_via_context",
        "target": "governance_gate",
        "description": "Attempt to emit a BLOCKED_CLAIM by embedding it in a free-text context field",
        "expected_defense": "Egress-time scan strips or blocks the claim string; disclosure attached.",
        "risk_if_bypassed": "CRITICAL",
    },
    {
        "id": "A2_msi_null_bypass_mmr",
        "target": "mmr_gate",
        "description": "Send MSI=None; gate should either fail-closed or require disclosure",
        "expected_defense": "mmr_gate refuses to score IO with null MSI, sets confidence cap.",
        "risk_if_bypassed": "HIGH",
    },
    {
        "id": "A3_prior_therapy_missing_platinum_bypass",
        "target": "platinum_gate",
        "description": "Send treatment_history=[]; gate should not conclude platinum-sensitive",
        "expected_defense": "platinum_gate refuses to declare sensitivity; degrades confidence.",
        "risk_if_bypassed": "HIGH",
    },
    {
        "id": "A4_pdl1_silent_drop_io_boost",
        "target": "io_engine",
        "description": "Populate PD-L1 CPS=50; verify it reaches IO score (P0 causality)",
        "expected_defense": "IO engine consumes PD-L1; W1's regression covers this.",
        "risk_if_bypassed": "HIGH",
    },
    {
        "id": "A5_all_zero_patient_vector",
        "target": "mechanism_fit",
        "description": "Send patient_vector = [0]*8; PATH A dot=0, fit=0 across all trials.",
        "expected_defense": "All fits 0.0; no ranked recommendation. Confidence tier LOCKED_NO_EXPRESSION.",
        "risk_if_bypassed": "MEDIUM",
    },
    {
        "id": "A6_axis_swap_confusion",
        "target": "vector_alignment",
        "description": "Send patient_vector with axes in wrong order (map her2 into ddr slot).",
        "expected_defense": "Canonical axis order enforced at contract boundary.",
        "risk_if_bypassed": "CRITICAL",
    },
    {
        "id": "A7_negative_biomarker_leak",
        "target": "therapy_fit",
        "description": "Trigger negative biomarker; ranker should quarantine to rank=999.",
        "expected_defense": "_QUARANTINE_RANK = 999 in scoring.py.",
        "risk_if_bypassed": "HIGH",
    },
    {
        "id": "A8_stubbed_impact_visible",
        "target": "therapy_fit",
        "description": "Verify that impact_score.value==0.5 is disclosed as STUBBED, not silently reported.",
        "expected_defense": "Response includes STUBBED tier + disclosure.",
        "risk_if_bypassed": "CRITICAL",
    },
    {
        "id": "A9_advisory_tier_downgrade",
        "target": "confidence_cap",
        "description": "Any output computed from stubbed/unwired data must be tagged ADVISORY_ONLY.",
        "expected_defense": "confidence_cap enforces tier ceiling.",
        "risk_if_bypassed": "CRITICAL",
    },
    {
        "id": "A10_path_b_reintroduction",
        "target": "mechanism_fit",
        "description": "Any code path that computes ||p||*||t|| instead of ||t|| is prohibited.",
        "expected_defense": "PATH_A_FORMULA constant + regression test in W1.",
        "risk_if_bypassed": "CRITICAL",
    },
]


def evaluate_attacks(gates: Dict[str, Any], gov: Dict[str, Any], confidence: Dict[str, Any],
                     leaks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Static-check whether the expected defense is present in the code.
    Static means: correct constant/function/predicate exists in the right file.
    Dynamic verification would require running the pipeline — deferred.
    """
    results = []
    def gate_has(name: str, needle: str) -> bool:
        g = gates.get(name, {})
        # Search functions + constants
        blob = " ".join([f["name"] for f in g.get("functions", [])])
        blob += " " + " ".join(g.get("constants", {}).keys())
        return needle in blob

    for a in ATTACKS:
        verdict = "PASS_STATIC"
        evidence = []
        aid = a["id"]

        if aid == "A1_blocked_claim_via_context":
            if not gov["BLOCKED_CLAIMS"]:
                verdict = "FAIL_STATIC"
                evidence.append("BLOCKED_CLAIMS list empty or unparseable")
            true_leaks = [L for L in leaks if L.get("verdict") == "LEAK"]
            reference_only = [L for L in leaks if L.get("verdict") == "REFERENCE_ONLY"]
            if true_leaks:
                verdict = "FAIL_STATIC"
                evidence.append(f"UNGUARDED leaks: {len(true_leaks)} files")
            if reference_only:
                evidence.append(f"guarded references (OK): {len(reference_only)} files")

        elif aid == "A2_msi_null_bypass_mmr":
            if "mmr_gate.py" not in gates:
                verdict = "FAIL_STATIC"; evidence.append("mmr_gate.py missing")

        elif aid == "A3_prior_therapy_missing_platinum_bypass":
            if "platinum_gate.py" not in gates:
                verdict = "FAIL_STATIC"; evidence.append("platinum_gate.py missing")

        elif aid == "A5_all_zero_patient_vector":
            # Requires SPE-side LOCKED_NO_EXPRESSION or ranker returning zeros only.
            spe_scorer = (REPO_V3 / "layer1_engines/spe_engine/scorer.py").read_text(errors="ignore")
            if "LOCKED_NO_EXPRESSION" not in spe_scorer:
                verdict = "FAIL_STATIC"; evidence.append("LOCKED_NO_EXPRESSION missing in spe_engine/scorer.py")
            else:
                evidence.append("LOCKED_NO_EXPRESSION present in spe_engine/scorer.py")

        elif aid == "A7_negative_biomarker_leak":
            th = (REPO_V3 / "layer1_engines/therapy_fit/scoring.py").read_text(errors="ignore")
            if "_QUARANTINE_RANK" not in th or "999" not in th:
                verdict = "FAIL_STATIC"; evidence.append("_QUARANTINE_RANK=999 not present")

        elif aid == "A8_stubbed_impact_visible":
            th = (REPO_V3 / "layer1_engines/therapy_fit/scoring.py").read_text(errors="ignore")
            if "STUB" not in th.upper() and "WIWFM" not in th.upper():
                verdict = "FAIL_STATIC"; evidence.append("No STUBBED marker in scoring.py")

        elif aid == "A9_advisory_tier_downgrade":
            cap = (REPO_V3 / "layer2_gates/confidence_cap.py")
            if cap.exists():
                cap_txt = cap.read_text(errors="ignore")
                if "ADVISORY" in cap_txt.upper() or "CAP" in cap_txt.upper():
                    evidence.append("confidence_cap has cap/advisory logic")
                else:
                    verdict = "FAIL_STATIC"; evidence.append("no cap/advisory keyword in confidence_cap.py")
            else:
                verdict = "FAIL_STATIC"; evidence.append("confidence_cap.py missing")

        elif aid == "A10_path_b_reintroduction":
            mf = (REPO_V3 / "layer1_engines/mechanism_fit/mechanism_fit_ranker.py").read_text(errors="ignore")
            forbidden_patterns = [
                "patient_magnitude * trial_magnitude",
                "trial_magnitude * patient_magnitude",
                "np.linalg.norm(patient_vector) * np.linalg.norm(trial_vector)",
            ]
            if any(p in mf for p in forbidden_patterns):
                verdict = "FAIL_STATIC"; evidence.append("PATH B pattern detected in ranker!")
            elif "PATH_A_FORMULA" not in mf:
                verdict = "FAIL_STATIC"; evidence.append("PATH_A_FORMULA constant not present")

        elif aid == "A6_axis_swap_confusion":
            # canonical_vectors + patient_state must both declare the same axis order.
            cv = REPO_V3 / "layer0_contracts/canonical_vectors.py"
            if not cv.exists():
                verdict = "WARN"
                evidence.append("canonical_vectors.py absent — axis order not centrally locked")

        elif aid == "A4_pdl1_silent_drop_io_boost":
            io_dir = REPO_V3 / "layer1_engines/io_engine"
            has_pdl1 = False
            for py in io_dir.rglob("*.py"):
                if "pd_l1" in py.read_text(errors="ignore").lower() or "PD-L1" in py.read_text(errors="ignore"):
                    has_pdl1 = True; break
            if not has_pdl1:
                verdict = "FAIL_STATIC"; evidence.append("io_engine appears not to reference PD-L1")

        results.append({**a, "verdict": verdict, "evidence": evidence})
    return results


# ------------------------------------------------------------------
# Confidence cap receipts (static)
# ------------------------------------------------------------------
def cap_receipts() -> Dict[str, Any]:
    cap = REPO_V3 / "layer2_gates/confidence_cap.py"
    if not cap.exists():
        return {"present": False}
    src = cap.read_text()
    tiers_found = re.findall(r"[A-Z][A-Z_]+(?:_ONLY|_TIER|_CAP)", src)
    return {
        "present": True,
        "path":    str(cap.relative_to(REPO_V3.parent)),
        "sha":     hashlib.sha256(cap.read_bytes()).hexdigest()[:16],
        "tier_tokens_found": sorted(set(tiers_found))[:25],
    }


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------
def main():
    print("[W4] Enumerating L2 gates...")
    gates = enumerate_gates()
    (OUT / "W4_gate_map.json").write_text(json.dumps(gates, indent=2))

    print("[W4] Governance registry extraction...")
    gov = extract_governance()
    (OUT / "W4_governance_registry.json").write_text(json.dumps(gov, indent=2))

    print("[W4] Egress surface scan...")
    surfaces = egress_surfaces()
    (OUT / "egress_surfaces.json").write_text(json.dumps(surfaces, indent=2))

    print("[W4] BLOCKED_CLAIMS leak scan...")
    leaks = blocked_claim_leak_scan(gov["BLOCKED_CLAIMS"])
    (OUT / "leaks.json").write_text(json.dumps(leaks, indent=2))

    print("[W4] Confidence + holistic inspection...")
    confidence = inspect_confidence()
    (OUT / "confidence_inspection.json").write_text(json.dumps(confidence, indent=2))

    print("[W4] Cap receipts...")
    cap = cap_receipts()
    (OUT / "W4_confidence_cap_receipts.json").write_text(json.dumps(cap, indent=2))

    print("[W4] Attack matrix evaluation...")
    verdicts = evaluate_attacks(gates, gov, confidence, leaks)
    (OUT / "attacks_evaluated.json").write_text(json.dumps(verdicts, indent=2))

    with (OUT / "W4_attack_matrix.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["id", "target", "description", "expected_defense", "risk_if_bypassed", "verdict", "evidence"])
        w.writeheader()
        for v in verdicts:
            w.writerow({
                "id": v["id"], "target": v["target"], "description": v["description"],
                "expected_defense": v["expected_defense"], "risk_if_bypassed": v["risk_if_bypassed"],
                "verdict": v["verdict"], "evidence": " | ".join(v["evidence"]),
            })

    # Human summary
    fails = [v for v in verdicts if v["verdict"].startswith("FAIL")]
    warns = [v for v in verdicts if v["verdict"].startswith("WARN")]
    lines = [
        "# W4 — Red-Team Findings",
        "",
        f"Generated: {datetime.now(timezone.utc).isoformat()}",
        f"L2 gates enumerated: {len(gates)}",
        f"BLOCKED_CLAIMS in governance: {len(gov['BLOCKED_CLAIMS'])}",
        f"BLOCKED_CLAIMS leaks in non-governance files: {len(leaks)}",
        f"Attacks evaluated: {len(verdicts)}",
        f"  PASS static:  {sum(1 for v in verdicts if v['verdict']=='PASS_STATIC')}",
        f"  WARN:         {len(warns)}",
        f"  FAIL:         {len(fails)}",
        "",
        "## Failures (static)",
    ]
    for v in fails:
        lines.append(f"- **{v['id']}** ({v['risk_if_bypassed']}) — {v['description']}")
        for e in v["evidence"]:
            lines.append(f"  - {e}")
    lines.append("")
    lines.append("## Warnings")
    for v in warns:
        lines.append(f"- **{v['id']}** — {v['description']}")
        for e in v["evidence"]:
            lines.append(f"  - {e}")
    lines.append("")
    lines.append("## Passes (static)")
    for v in verdicts:
        if v["verdict"] == "PASS_STATIC":
            lines.append(f"- {v['id']} ({v['target']}) — {v['description']}")
    lines.append("")
    lines.append("## Notes")
    lines.append("- 'PASS_STATIC' means the expected defense predicate/constant/file is present in code.")
    lines.append("- Dynamic verification (actual pipeline runs with adversarial inputs) is deferred to W3/W5.")
    lines.append("- Any FAIL_STATIC must be closed before release. WARNs require a design decision.")
    (OUT / "W4_redteam_findings.md").write_text("\n".join(lines) + "\n")

    print("[W4] DONE.")
    print(f"[W4] FAILs: {len(fails)}, WARNs: {len(warns)}, leaks: {len(leaks)}")


if __name__ == "__main__":
    main()
