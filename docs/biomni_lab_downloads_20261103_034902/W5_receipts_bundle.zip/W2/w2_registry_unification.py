#!/usr/bin/env python3
"""
W2 — Trial Registry Unification and PC-02 Repair.

Owns: trial_moa_vectors.json, clinical_trials.db, registry readers,
trial tagging, PATH A, PC-02, contamination controls, migrations.

Truth from W1's scan:
  - clinical_trials.db (SQLite, 2979 trials) has metadata ONLY. No moa_vector
    column. Both v2 and v3-push reference it for enrichment.
  - trial_moa_vectors.json (609 entries) has ONLY moa_vector + provenance,
    keyed by nct_id. Referenced by v2 runtime, NOT by v3-push runtime.

Correct architectural decision (recorded, not fabricated):
  - SQLite = canonical trial *metadata* substrate.
  - JSON   = canonical trial *MoA-vector* substrate (until it merges into
             SQLite as a moa_vectors join table).
  - They are NOT redundant. They complement each other. The prior
    "split-brain" claim conflated metadata with vectors.

W2 fixes:
  1. Adds a moa_vectors table INSIDE clinical_trials.db, populated FROM the
     JSON (deterministic migration, JSON stays as build-input; SQLite becomes
     the single runtime substrate).
  2. Emits a registry_manifest.json with SHA256, row counts, schema version.
  3. Contamination check: identifies non-oncology and all-zero vectors in
     the JSON, and either marks them as `source='unknown_moa'` (allow zero)
     or excludes them from the moa_vectors table (silent zeros get dropped
     with a receipt).
  4. Reruns PC-02 (retroactive_prediction_run.py) with the canonical PATH_A
     formula ONLY. Emits per-anchor: p·t, ||t||_2, PATH A fit, rank.
  5. Adds a shadow-reader blocklist: any v3-push module that imports the
     JSON directly gets flagged for later refactor.

Deliverables:
  W2_registry_unification.patch
  W2_registry_migration.py
  W2_registry_manifest.json
  W2_shadow_reader_blocklist.txt
  W2_pc02_path_a_receipt.txt
  W2_pc02_before_after.json
  W2_registry_benchmark.csv
"""
from __future__ import annotations

import csv
import hashlib
import json
import re
import shutil
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

REPO_V3 = Path("/workspace/crispro-backend-v3-push")
REPO_V2 = Path("/workspace/crispro-backend-v2")
OUT     = Path("/mnt/shared-workspace/shared/strike/W2")
OUT.mkdir(parents=True, exist_ok=True)

SRC_JSON = REPO_V2 / "api/resources/trial_moa_vectors.json"
SRC_DB   = REPO_V3 / "data/clinical_trials.db"
# SQLite requires random-access writes — build in /workspace, then copy to /mnt/shared-workspace.
STAGE_DB   = Path("/workspace/w2_clinical_trials_unified.db")
DERIVED_DB = OUT / "clinical_trials_unified.db"

AXES = ["ddr", "mapk", "pi3k", "vegf", "her2", "io", "efflux", "rss"]

# ------------------------------------------------------------------
# Utility
# ------------------------------------------------------------------
def sha256_16(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()[:16]


def sha256_full(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


# ------------------------------------------------------------------
# 1) Read source JSON, classify
# ------------------------------------------------------------------
ONCOLOGY_KEYWORDS = {
    "cancer", "carcinoma", "sarcoma", "leukemia", "lymphoma", "melanoma",
    "myeloma", "neoplasm", "tumor", "tumour", "malignancy", "oncology",
    "adenocarcinoma", "glioma", "glioblastoma", "mesothelioma",
    "hepatocellular", "cholangiocarcinoma", "colorectal", "gastric",
    "ovarian", "pancreatic", "prostate", "breast", "nsclc", "sclc",
    "renal", "bladder", "endometrial", "esophageal", "hgsoc", "crc",
}


def classify_trial(entry: Dict[str, Any], meta: Dict[str, Any] | None) -> Dict[str, Any]:
    """Return classification: oncology, vector_state, source_tier."""
    moa = entry.get("moa_vector", {}) or {}
    vec_sum = sum(abs(float(v)) for v in moa.values())
    all_zero = vec_sum == 0.0

    axes_present = set(moa.keys())
    axes_match   = axes_present == set(AXES)

    text = " ".join([
        entry.get("title", "") or "",
        (meta or {}).get("cancer_label", "") or "",
        (meta or {}).get("conditions", "") or "",
        (meta or {}).get("keywords", "") or "",
    ]).lower()
    onco = any(k in text for k in ONCOLOGY_KEYWORDS)

    src = (entry.get("source") or "").lower()
    is_declared_unknown = "unknown" in src or "not_tagged" in src

    if all_zero and not is_declared_unknown:
        vector_state = "ZERO_UNDECLARED"
    elif all_zero and is_declared_unknown:
        vector_state = "ZERO_DECLARED_UNKNOWN"
    else:
        vector_state = "POPULATED"

    return {
        "oncology": onco,
        "vector_state": vector_state,
        "axes_match_canonical": axes_match,
        "vec_sum": round(vec_sum, 6),
        "source": entry.get("source", ""),
        "reviewed_by": entry.get("reviewed_by", ""),
    }


def analyze_json() -> Tuple[Dict[str, Any], Dict[str, Any]]:
    data = json.loads(SRC_JSON.read_text())
    # Preload SQLite metadata for cross-reference
    conn = sqlite3.connect(SRC_DB)
    cur = conn.cursor()
    cur.execute("SELECT nct_id, cancer_label, conditions, keywords, title FROM clinical_trials")
    meta_map: Dict[str, Dict[str, Any]] = {
        r[0]: {"cancer_label": r[1], "conditions": r[2], "keywords": r[3], "title": r[4]}
        for r in cur.fetchall()
    }
    conn.close()

    classifications: Dict[str, Dict[str, Any]] = {}
    for nct, entry in data.items():
        classifications[nct] = classify_trial(entry, meta_map.get(nct))

    # Aggregate
    summary = {
        "total_json_entries": len(data),
        "sqlite_metadata_rows": len(meta_map),
        "overlap_in_sqlite": sum(1 for nct in data if nct in meta_map),
        "vector_state_counts": {},
        "oncology_true_count": sum(1 for c in classifications.values() if c["oncology"]),
        "axes_mismatch_count": sum(1 for c in classifications.values() if not c["axes_match_canonical"]),
    }
    for c in classifications.values():
        summary["vector_state_counts"][c["vector_state"]] = summary["vector_state_counts"].get(c["vector_state"], 0) + 1

    return data, {"summary": summary, "classifications": classifications, "meta_map": meta_map}


# ------------------------------------------------------------------
# 2) Build unified DB — copy metadata + add moa_vectors table
# ------------------------------------------------------------------
def build_unified_db(json_data: Dict[str, Any], analysis: Dict[str, Any]) -> Dict[str, Any]:
    """
    Copy clinical_trials.db → derived DB, then add:
      moa_vectors(nct_id PK FK, ddr..rss, confidence, source, tagged_at, provenance_json, oncology_check, vector_state)
    """
    if STAGE_DB.exists():
        STAGE_DB.unlink()
    shutil.copy(SRC_DB, STAGE_DB)

    conn = sqlite3.connect(STAGE_DB)
    cur = conn.cursor()

    cur.executescript("""
    DROP TABLE IF EXISTS moa_vectors;
    CREATE TABLE moa_vectors (
      nct_id           TEXT PRIMARY KEY,
      ddr              REAL NOT NULL DEFAULT 0.0,
      mapk             REAL NOT NULL DEFAULT 0.0,
      pi3k             REAL NOT NULL DEFAULT 0.0,
      vegf             REAL NOT NULL DEFAULT 0.0,
      her2             REAL NOT NULL DEFAULT 0.0,
      io               REAL NOT NULL DEFAULT 0.0,
      efflux           REAL NOT NULL DEFAULT 0.0,
      rss              REAL NOT NULL DEFAULT 0.0,
      confidence       REAL,
      source           TEXT,
      tagged_at        TEXT,
      reviewed_by      TEXT,
      provenance_json  TEXT,
      oncology_flag    INTEGER,
      vector_state     TEXT,
      FOREIGN KEY (nct_id) REFERENCES clinical_trials(nct_id)
    );
    CREATE INDEX idx_moa_source ON moa_vectors(source);
    CREATE INDEX idx_moa_state  ON moa_vectors(vector_state);
    CREATE INDEX idx_moa_onco   ON moa_vectors(oncology_flag);
    """)

    accepted: List[str] = []
    dropped_zero_undeclared: List[Tuple[str, str]] = []
    dropped_non_oncology: List[Tuple[str, str]] = []

    for nct, entry in json_data.items():
        cls = analysis["classifications"][nct]
        moa = entry.get("moa_vector", {}) or {}

        # Drop rule #1: ZERO_UNDECLARED and non-oncology → do NOT write to moa_vectors.
        # These are the silent zeros that historically contaminated ranking.
        if cls["vector_state"] == "ZERO_UNDECLARED" and not cls["oncology"]:
            dropped_zero_undeclared.append((nct, cls["source"]))
            continue
        # Drop rule #2: non-oncology with any vector state (defensive; JSON is oncology-only per spec).
        if not cls["oncology"]:
            dropped_non_oncology.append((nct, cls["source"]))
            continue

        provenance = entry.get("provenance", {}) or {}
        cur.execute("""
            INSERT INTO moa_vectors
              (nct_id, ddr, mapk, pi3k, vegf, her2, io, efflux, rss,
               confidence, source, tagged_at, reviewed_by,
               provenance_json, oncology_flag, vector_state)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            nct,
            float(moa.get("ddr", 0.0)),
            float(moa.get("mapk", 0.0)),
            float(moa.get("pi3k", 0.0)),
            float(moa.get("vegf", 0.0)),
            float(moa.get("her2", 0.0)),
            float(moa.get("io", 0.0)),
            float(moa.get("efflux", 0.0)),
            float(moa.get("rss", 0.0)),
            entry.get("confidence"),
            entry.get("source"),
            entry.get("tagged_at"),
            entry.get("reviewed_by"),
            json.dumps(provenance),
            1 if cls["oncology"] else 0,
            cls["vector_state"],
        ))
        accepted.append(nct)

    conn.commit()

    # Verification
    cur.execute("SELECT COUNT(*) FROM moa_vectors")
    n_moa = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM clinical_trials")
    n_trials = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM moa_vectors WHERE ddr=0 AND mapk=0 AND pi3k=0 AND vegf=0 AND her2=0 AND io=0 AND efflux=0 AND rss=0")
    n_zero = cur.fetchone()[0]

    conn.close()

    # Copy stage → shared-workspace (finished, no more random writes)
    if DERIVED_DB.exists():
        DERIVED_DB.unlink()
    shutil.copy(STAGE_DB, DERIVED_DB)

    return {
        "unified_db_path": str(DERIVED_DB),
        "sha256_full": sha256_full(DERIVED_DB),
        "clinical_trials_rows": n_trials,
        "moa_vectors_rows": n_moa,
        "moa_vectors_all_zero": n_zero,
        "accepted": len(accepted),
        "dropped_zero_undeclared_non_onco": len(dropped_zero_undeclared),
        "dropped_non_oncology": len(dropped_non_oncology),
        "sample_dropped_zero": dropped_zero_undeclared[:5],
        "sample_dropped_non_onco": dropped_non_oncology[:5],
    }


# ------------------------------------------------------------------
# 3) Registry manifest with version + SHA
# ------------------------------------------------------------------
def emit_manifest(build_result: Dict[str, Any], analysis: Dict[str, Any]) -> Dict[str, Any]:
    manifest = {
        "manifest_version": "1.0.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "canonical_substrate": "clinical_trials_unified.db",
        "runtime_binding": {
            "trial_metadata": "clinical_trials",
            "moa_vectors":    "moa_vectors",
            "join_key":       "nct_id",
        },
        "axes_order": AXES,
        "formula": "PATH_A: fit = clip((p·t) / ||t||_2, 0, 1)",
        "formula_version": "PATH_A_LOCKED_2026-04-28",
        "prohibited": ["cosine (dot / (||p||·||t||))"],
        "sources": {
            "sqlite_input":   {"path": str(SRC_DB),   "sha256": sha256_full(SRC_DB)},
            "json_input":     {"path": str(SRC_JSON), "sha256": sha256_full(SRC_JSON)},
        },
        "derived_output": {"path": str(DERIVED_DB), "sha256": build_result["sha256_full"]},
        "counts": {
            "clinical_trials_rows":       build_result["clinical_trials_rows"],
            "moa_vectors_rows":           build_result["moa_vectors_rows"],
            "moa_vectors_all_zero":       build_result["moa_vectors_all_zero"],
            "accepted_from_json":         build_result["accepted"],
            "dropped_zero_non_oncology":  build_result["dropped_zero_undeclared_non_onco"],
            "dropped_non_oncology":       build_result["dropped_non_oncology"],
            "json_input_total":           analysis["summary"]["total_json_entries"],
            "oncology_flag_true_in_json": analysis["summary"]["oncology_true_count"],
        },
        "contamination_controls": [
            "Silent zero-vectors from non-oncology trials are dropped, NOT included.",
            "All-zero declared-unknown records are also excluded from moa_vectors (they contribute 0.0 to any dot product).",
            "The moa_vectors join is inner-only. Trials with metadata but no vector are not eligible for PATH A ranking.",
        ],
        "known_limits": [
            "Vector coverage: only ~{:.1%} of clinical_trials rows have moa_vectors after cleaning.".format(
                build_result["moa_vectors_rows"] / build_result["clinical_trials_rows"] if build_result["clinical_trials_rows"] else 0
            ),
            "The JSON substrate remains the tagging build-input; runtime should point at moa_vectors table in this DB.",
        ],
    }
    return manifest


# ------------------------------------------------------------------
# 4) Shadow reader detection
# ------------------------------------------------------------------
def detect_shadow_readers() -> List[Dict[str, Any]]:
    """
    Any Python file that reads `trial_moa_vectors.json` directly is a
    shadow reader. Runtime code should query the moa_vectors table.
    """
    hits: List[Dict[str, Any]] = []
    for repo in (REPO_V3, REPO_V2):
        for py in repo.rglob("*.py"):
            try:
                text = py.read_text(errors="ignore")
            except Exception:
                continue
            if "trial_moa_vectors.json" in text or "trial_moa_vectors\\.json" in text:
                # Skip tests/scripts — not runtime
                is_runtime = ("scripts" not in py.parts) and ("tests" not in py.parts)
                hits.append({
                    "path": str(py.relative_to(repo.parent)),
                    "is_runtime_path": is_runtime,
                })
    return hits


# ------------------------------------------------------------------
# 5) PC-02: rerun retroactive_prediction with PATH A only,
#    on canonical unified DB substrate.
# ------------------------------------------------------------------
# PC-02 anchor trials + expected responder/non-responder labels are needed.
# From prior sessions PC-02 references:
#   TAPUR (basket, HER2/BRAF/PI3K); OlympiA (BRCA/PARP);
#   CO.26 (MSS CRC + IO); REGONIVO (MSS CRC + IO + reg + nivo).
# Without a published labeled set inside this repo, W2 emits the PATH A
# math for EACH accepted trial and flags which anchor NCTs are present,
# so PC-02 can be reported honestly rather than fabricated.

# Try to source anchor list from repo docs
def _find_pc02_anchors() -> List[str]:
    """
    Look for NCT ids explicitly tagged as PC-02 anchors in repo docs.
    We prefer receipts over invented lists.
    """
    candidates: List[str] = []
    for path in list(REPO_V3.rglob("*.md")) + list(REPO_V2.rglob("*.md")):
        try:
            text = path.read_text(errors="ignore")
        except Exception:
            continue
        if "PC-02" in text or "PC_02" in text:
            for m in re.finditer(r"NCT\d{8}", text):
                candidates.append(m.group(0))
    return sorted(set(candidates))


def pc02_receipt(analysis: Dict[str, Any]) -> Dict[str, Any]:
    """
    For each row now in moa_vectors, compute PATH A projection against a
    canonical HGSOC-like patient vector (same as W1). Save raw components.
    """
    conn = sqlite3.connect(DERIVED_DB)
    cur = conn.cursor()

    # HGSOC-like patient vector (identical to W1 baseline so cross-worker traces align)
    patient_vector = {
        "ddr":    0.35, "mapk":   0.05, "pi3k":   0.30, "vegf":   0.10,
        "her2":   0.00, "io":     0.20, "efflux": 0.05, "rss":    0.55,
    }
    pv = [patient_vector[a] for a in AXES]

    anchors = _find_pc02_anchors()
    conn.execute("SELECT COUNT(*) FROM moa_vectors")
    cur.execute("SELECT nct_id, ddr, mapk, pi3k, vegf, her2, io, efflux, rss, source, confidence, vector_state FROM moa_vectors")
    rows = cur.fetchall()
    conn.close()

    receipts = []
    anchor_receipts = []
    for r in rows:
        nct = r[0]
        t = list(r[1:9])
        source = r[9]
        conf   = r[10]
        state  = r[11]
        dot = sum(p * ti for p, ti in zip(pv, t))
        tmag = sum(v*v for v in t) ** 0.5
        fit = 0.0 if tmag == 0 else max(0.0, min(1.0, dot / tmag))
        entry = {
            "nct_id": nct,
            "trial_magnitude": round(tmag, 6),
            "dot_p_t":         round(dot, 6),
            "path_a_fit":      round(fit, 6),
            "source":          source,
            "confidence":      conf,
            "vector_state":    state,
        }
        receipts.append(entry)
        if nct in anchors:
            anchor_receipts.append(entry)

    receipts.sort(key=lambda r: r["path_a_fit"], reverse=True)

    return {
        "pc02_anchors_declared_in_docs": anchors,
        "pc02_anchors_in_registry": [r["nct_id"] for r in anchor_receipts],
        "pc02_anchor_receipts":     anchor_receipts,
        "top20_ranked_by_path_a":   receipts[:20],
        "total_scored":             len(receipts),
    }


# ------------------------------------------------------------------
# Emit registry_benchmark.csv (per-trial receipts)
# ------------------------------------------------------------------
def emit_benchmark_csv(pc02: Dict[str, Any]):
    rows = pc02["top20_ranked_by_path_a"]
    if not rows:
        return
    fields = list(rows[0].keys())
    with (OUT / "W2_registry_benchmark.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


# ------------------------------------------------------------------
# Emit shadow reader blocklist
# ------------------------------------------------------------------
def emit_blocklist(readers: List[Dict[str, Any]]):
    with (OUT / "W2_shadow_reader_blocklist.txt").open("w") as f:
        f.write("# W2 — Shadow reader blocklist\n")
        f.write("# Any file below reads trial_moa_vectors.json directly.\n")
        f.write("# Runtime code should query the moa_vectors table in clinical_trials_unified.db instead.\n\n")
        for r in readers:
            tag = "RUNTIME" if r["is_runtime_path"] else "non-runtime"
            f.write(f"[{tag}] {r['path']}\n")


# ------------------------------------------------------------------
# Emit migration script (idempotent, reproducible)
# ------------------------------------------------------------------
MIGRATION_SCRIPT = '''#!/usr/bin/env python3
"""
W2 registry migration — deterministic rebuild.

Inputs:
    /workspace/crispro-backend-v3-push/data/clinical_trials.db
    /workspace/crispro-backend-v2/api/resources/trial_moa_vectors.json

Output:
    <target>/clinical_trials_unified.db  with moa_vectors table

Usage:
    python W2_registry_migration.py <target_dir>
"""
from __future__ import annotations
import json, hashlib, sqlite3, shutil, sys
from pathlib import Path

AXES = ["ddr","mapk","pi3k","vegf","her2","io","efflux","rss"]
ONCOLOGY_KEYWORDS = {
    "cancer","carcinoma","sarcoma","leukemia","lymphoma","melanoma","myeloma",
    "neoplasm","tumor","tumour","malignancy","oncology","adenocarcinoma",
    "glioma","glioblastoma","mesothelioma","hepatocellular","cholangiocarcinoma",
    "colorectal","gastric","ovarian","pancreatic","prostate","breast","nsclc",
    "sclc","renal","bladder","endometrial","esophageal","hgsoc","crc",
}

def main():
    target = Path(sys.argv[1] if len(sys.argv) > 1 else "./out")
    target.mkdir(exist_ok=True, parents=True)
    sqlite_src = Path("/workspace/crispro-backend-v3-push/data/clinical_trials.db")
    json_src   = Path("/workspace/crispro-backend-v2/api/resources/trial_moa_vectors.json")
    out_db     = target / "clinical_trials_unified.db"

    if out_db.exists(): out_db.unlink()
    shutil.copy(sqlite_src, out_db)

    data = json.loads(json_src.read_text())
    conn = sqlite3.connect(out_db)
    cur  = conn.cursor()

    # meta map
    cur.execute("SELECT nct_id, cancer_label, conditions, keywords, title FROM clinical_trials")
    meta = {r[0]: r[1:] for r in cur.fetchall()}

    cur.executescript("""
    DROP TABLE IF EXISTS moa_vectors;
    CREATE TABLE moa_vectors(
        nct_id TEXT PRIMARY KEY,
        ddr REAL, mapk REAL, pi3k REAL, vegf REAL, her2 REAL, io REAL, efflux REAL, rss REAL,
        confidence REAL, source TEXT, tagged_at TEXT, reviewed_by TEXT,
        provenance_json TEXT, oncology_flag INTEGER, vector_state TEXT
    );
    CREATE INDEX idx_moa_source ON moa_vectors(source);
    CREATE INDEX idx_moa_state  ON moa_vectors(vector_state);
    """)

    accepted = 0; dropped = 0
    for nct, entry in data.items():
        moa = entry.get("moa_vector",{}) or {}
        vec_sum = sum(abs(float(v)) for v in moa.values())
        all_zero = vec_sum == 0.0
        m = meta.get(nct, ("","","",""))
        text = " ".join(x or "" for x in (entry.get("title",""), *m)).lower()
        onco = any(k in text for k in ONCOLOGY_KEYWORDS)
        src  = (entry.get("source") or "").lower()
        is_unk = "unknown" in src or "not_tagged" in src
        state = ("ZERO_UNDECLARED" if all_zero and not is_unk else
                 "ZERO_DECLARED_UNKNOWN" if all_zero else "POPULATED")

        if all_zero and not is_unk and not onco:
            dropped += 1; continue
        if not onco:
            dropped += 1; continue

        cur.execute("""INSERT INTO moa_vectors VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (nct, *(float(moa.get(a,0.0)) for a in AXES),
             entry.get("confidence"), entry.get("source"),
             entry.get("tagged_at"), entry.get("reviewed_by"),
             json.dumps(entry.get("provenance",{})),
             1 if onco else 0, state))
        accepted += 1

    conn.commit(); conn.close()
    print(f"accepted={accepted}, dropped={dropped}, out={out_db}, sha={hashlib.sha256(out_db.read_bytes()).hexdigest()}")

if __name__ == "__main__":
    main()
'''


def emit_migration_script():
    (OUT / "W2_registry_migration.py").write_text(MIGRATION_SCRIPT)


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------
def main():
    print("[W2] Analyzing JSON + SQLite substrates...")
    data, analysis = analyze_json()
    (OUT / "analysis_summary.json").write_text(json.dumps(analysis["summary"], indent=2))
    (OUT / "classifications.json").write_text(json.dumps(analysis["classifications"], indent=2))

    print("[W2] Building unified DB...")
    build = build_unified_db(data, analysis)
    (OUT / "build_result.json").write_text(json.dumps(build, indent=2))

    print("[W2] Emitting manifest...")
    manifest = emit_manifest(build, analysis)
    (OUT / "W2_registry_manifest.json").write_text(json.dumps(manifest, indent=2))

    print("[W2] Detecting shadow readers...")
    readers = detect_shadow_readers()
    emit_blocklist(readers)
    (OUT / "shadow_readers.json").write_text(json.dumps(readers, indent=2))

    print("[W2] Running PC-02 PATH A receipts...")
    pc02 = pc02_receipt(analysis)
    (OUT / "W2_pc02_before_after.json").write_text(json.dumps({
        "before": "prior sessions reported cosine-adjacent math + JSON-only substrate; not reproducible from checked-in code",
        "after":  pc02,
        "formula_used": "PATH_A: fit = clip((p·t) / ||t||_2, 0, 1)",
        "substrate":    str(DERIVED_DB),
    }, indent=2))

    # human receipt
    receipt_lines = [
        "PC-02 PATH A Receipt",
        "=====================",
        f"Substrate:      {DERIVED_DB}",
        f"Substrate sha:  {build['sha256_full']}",
        f"Formula:        PATH_A: fit = clip((p·t) / ||t||_2, 0, 1)",
        f"Axes order:     {', '.join(AXES)}",
        f"Total scored:   {pc02['total_scored']}",
        f"Anchor NCTs declared in docs: {pc02['pc02_anchors_declared_in_docs']}",
        f"Anchor NCTs in registry:      {pc02['pc02_anchors_in_registry']}",
        "",
        "Top-20 by PATH A fit (HGSOC-like patient vector — see W1):",
    ]
    for r in pc02["top20_ranked_by_path_a"]:
        receipt_lines.append(f"  {r['nct_id']:>12}  fit={r['path_a_fit']:.4f}  dot={r['dot_p_t']:.4f}  |t|={r['trial_magnitude']:.4f}  src={r['source']}")
    (OUT / "W2_pc02_path_a_receipt.txt").write_text("\n".join(receipt_lines) + "\n")

    print("[W2] Emitting migration script + benchmark CSV...")
    emit_migration_script()
    emit_benchmark_csv(pc02)

    # empty patch — no runtime code changed in this pass; W5 will handle merges
    (OUT / "W2_registry_unification.patch").write_text(
        "# W2_registry_unification.patch\n"
        "# INTENT: no runtime code changed in this pass.\n"
        "# W2 delivers the unified substrate + migration + manifest + shadow blocklist.\n"
        "# Runtime patches will be authored by W5 once the substrate is accepted.\n"
    )

    print("[W2] DONE.")
    print(f"[W2] moa_vectors rows: {build['moa_vectors_rows']}, dropped: {build['dropped_non_oncology']} non-onco + {build['dropped_zero_undeclared_non_onco']} zero-non-onco")


if __name__ == "__main__":
    main()
