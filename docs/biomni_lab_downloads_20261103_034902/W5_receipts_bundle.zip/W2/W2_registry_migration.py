#!/usr/bin/env python3
"""
W2 registry migration — deterministic rebuild.

Inputs:
    /workspace/crispro-backend-v3-push/data/clinical_trials.db
    /workspace/crispro-backend-v2/api/resources/trial_moa_vectors.json

Output:
    <target>/clinical_trials_unified.db  with moa_vectors table

Usage:
    python W2_registry_migration.py <target_dir>
"""
from __future__ import annotations
import json, hashlib, sqlite3, shutil, sys
from pathlib import Path

AXES = ["ddr","mapk","pi3k","vegf","her2","io","efflux","rss"]
ONCOLOGY_KEYWORDS = {
    "cancer","carcinoma","sarcoma","leukemia","lymphoma","melanoma","myeloma",
    "neoplasm","tumor","tumour","malignancy","oncology","adenocarcinoma",
    "glioma","glioblastoma","mesothelioma","hepatocellular","cholangiocarcinoma",
    "colorectal","gastric","ovarian","pancreatic","prostate","breast","nsclc",
    "sclc","renal","bladder","endometrial","esophageal","hgsoc","crc",
}

def main():
    target = Path(sys.argv[1] if len(sys.argv) > 1 else "./out")
    target.mkdir(exist_ok=True, parents=True)
    sqlite_src = Path("/workspace/crispro-backend-v3-push/data/clinical_trials.db")
    json_src   = Path("/workspace/crispro-backend-v2/api/resources/trial_moa_vectors.json")
    out_db     = target / "clinical_trials_unified.db"

    if out_db.exists(): out_db.unlink()
    shutil.copy(sqlite_src, out_db)

    data = json.loads(json_src.read_text())
    conn = sqlite3.connect(out_db)
    cur  = conn.cursor()

    # meta map
    cur.execute("SELECT nct_id, cancer_label, conditions, keywords, title FROM clinical_trials")
    meta = {r[0]: r[1:] for r in cur.fetchall()}

    cur.executescript("""
    DROP TABLE IF EXISTS moa_vectors;
    CREATE TABLE moa_vectors(
        nct_id TEXT PRIMARY KEY,
        ddr REAL, mapk REAL, pi3k REAL, vegf REAL, her2 REAL, io REAL, efflux REAL, rss REAL,
        confidence REAL, source TEXT, tagged_at TEXT, reviewed_by TEXT,
        provenance_json TEXT, oncology_flag INTEGER, vector_state TEXT
    );
    CREATE INDEX idx_moa_source ON moa_vectors(source);
    CREATE INDEX idx_moa_state  ON moa_vectors(vector_state);
    """)

    accepted = 0; dropped = 0
    for nct, entry in data.items():
        moa = entry.get("moa_vector",{}) or {}
        vec_sum = sum(abs(float(v)) for v in moa.values())
        all_zero = vec_sum == 0.0
        m = meta.get(nct, ("","","",""))
        text = " ".join(x or "" for x in (entry.get("title",""), *m)).lower()
        onco = any(k in text for k in ONCOLOGY_KEYWORDS)
        src  = (entry.get("source") or "").lower()
        is_unk = "unknown" in src or "not_tagged" in src
        state = ("ZERO_UNDECLARED" if all_zero and not is_unk else
                 "ZERO_DECLARED_UNKNOWN" if all_zero else "POPULATED")

        if all_zero and not is_unk and not onco:
            dropped += 1; continue
        if not onco:
            dropped += 1; continue

        cur.execute("""INSERT INTO moa_vectors VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (nct, *(float(moa.get(a,0.0)) for a in AXES),
             entry.get("confidence"), entry.get("source"),
             entry.get("tagged_at"), entry.get("reviewed_by"),
             json.dumps(entry.get("provenance",{})),
             1 if onco else 0, state))
        accepted += 1

    conn.commit(); conn.close()
    print(f"accepted={accepted}, dropped={dropped}, out={out_db}, sha={hashlib.sha256(out_db.read_bytes()).hexdigest()}")

if __name__ == "__main__":
    main()
